-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 01 Nov 2020 pada 17.52
-- Versi server: 10.4.11-MariaDB
-- Versi PHP: 7.4.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `stki`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `berita`
--

CREATE TABLE `berita` (
  `id` int(5) NOT NULL,
  `judul` tinytext NOT NULL,
  `isi` text NOT NULL,
  `url` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `berita`
--

INSERT INTO `berita` (`id`, `judul`, `isi`, `url`) VALUES
(1, 'Kajian Kitab Kuning', 'Selain berkonsentrasi pada program Bahasa dan Tahfidzul Qur’an, PonPes Al-Munawaroh juga mendidik santrinya agar mampu menguasai kajian kitab salaf supaya dapat bersaing dengan santri-santri pondok salaf dan juga mempertahankan peradapan pondok-pondok terdahulu.', 'https://www.almunawaroh.sch.id/kajian-kitab-kuning/'),
(2, 'Kajian Kitab Kuning', 'Program pendidikan yang diselenggarakan Kabid. Pendidikan dan Pengajaran Dewan Ma’hadiyah Pondok Pesantren Mambaul Ulum Bata-Bata pada hari aktif pesantren, terdiri dari berbagai macam program dan penyelenggaraannya berada dibawah koordinasi Pengurus Dewan Ma’hadiyah. Sama halnya dengan kebanyakan pesantren lain, program ini adalah ruh dari kegiatan pesantren, mengingat sejak awal berdirinya Pondok Pesantren Mambaul Ulum Bata-Bata, program ini pun berjalan sampai saat ini.\r\n\r\nProgram pengajian kitab kuning ini diharapkan dapat mengasah kemampuan santri dalam membaca kitab kuning yang merupakan ciri khas dari pondok pesantren. dalam aplikasinya, program pengajian kitab kuning ini diselenggarakan secara berjenjang, berdasarkan tingkat pendidikan formall santri.', 'http://bata-bata.net/page/Kajian-Kitab-Kuning.html'),
(3, 'Tradisi Kajian Kitab Kuning Pesantren Salafi Banten saat Wabah Corona', 'Santri asuhan KH Daud Yusuf ini memutuskan untuk ramai-ramai mengkaji dan memperdalam kajian kitab kuning selama bulan suci Ramadhan. Tujuannya untuk meningkatkan kompetensi santri untuk menguasai bidang ilmu fiqh, tasauf hingga akidah Islam.\r\nMereka fokus mengupas tentang kitab Kitab “Nihayatu Az-Zain” karya An Nawawi Al-Jawi dari kampung Tanara Provinsi Banten dan wafat tahun 1317 H atau 1316 H.', 'https://banten.suara.com/read/2020/04/27/160500/tradisi-kajian-kitab-kuning-pesantren-salafi-banten-saat-wabah-corona?page=all'),
(4, 'Begini Pondok Pesantren Lebak Belajar Kitab Kuning Saat Ramadan', 'Sejumlah pondok pesantren di Kabupaten Lebak, Provinsi Banten memperdalam kajian \"kitab kuning\" atau \"kitab gundul” selama bulan suci Ramadhan 1441 Hijriah. Hal itu untuk meningkatkan kompetensi kemampuan santri dalam menguasai bidang ilmu fiqh, tasawuf hingga akidah Islam.\r\nami setiap Ramadhan mengkaji \'kitab kuning\' secara khusus untuk memperdalam Kitab \"Nihayati Az-Zain\", \" kata pimpinan Pondok Pesantren (Ponpes) Nurul Ihsan Kalanganyar Kabupaten Lebak, KH Daud Yusuf di Lebak, Ahad, 26 April 2020.', 'https://ramadan.tempo.co/read/1335769/begini-pondok-pesantren-lebak-belajar-kitab-kuning-saat-ramadan'),
(5, 'Santri Asshodiqiyah Semarang Kajian Kitab Kuning Online di Tengah Pandemi Covid-19', 'Di tengah pandemi covid-19, ratusan santri pondok pesantren Asshodiqiyah Semarang mendalami kitab kuning secara online dan physical distancing. Aktivitas pendalaman kitab kuning dilakukan karena sudah menjadi tradisi setiap bulan ramadan.\r\nantri Asshodiqiyah Semarang Mengkaji Kitab Kuning Secara Online. ©2020 Merdeka.com/Danny Adriadhi Utama\r\nMerdeka.com - Di tengah pandemi covid-19, ratusan santri pondok pesantren Asshodiqiyah Semarang mendalami kitab kuning secara online dan physical distancing. Aktivitas pendalaman kitab kuning dilakukan karena sudah menjadi tradisi setiap bulan ramadan.\r\n\r\nSebelum mengikuti pendalaman kitab kuning, setiap santri dilakukan pengecekan suhu badan. Tampak para santri memanfaatkan libur panjang untuk berbagai macam aktivitas dengan \"ngaji kilatan\". Mereka yang hadir secara khusyuk menyimak Alquran gundul yang dibacakan oleh guru ngaji.', 'https://www.merdeka.com/peristiwa/santri-asshodiqiyah-semarang-kajian-kitab-kuning-online-di-tengah-pandemi-covid-19.html'),
(6, 'Sejumlah Pesantren Lebak Kaji Kitab Kuning Selama Ramadhan', 'Sejumlah pondok pesantren (ponpes) di Kabupaten Lebak, Provinsi Banten memperdalam kajian kitab kuning selama Ramadhan 1441 Hijriyah. Hal ini untuk meningkatkan kompetensi kemampuan santri dalam menguasai bidang ilmu fiqih, tasawuf hingga akidah Islam\r\nPengkajian Kitab \"Nihayati Az-Zain\" itu untuk mengkaji secara khusus untuk mendalami ilmu fiqih, tasawuf, dan akidah Islam.', 'https://republika.co.id/berita/q9dqv0320/sejumlah-pesantren-lebak-kaji-kitab-kuning-selama-ramadhan'),
(7, 'Pembelajaran Kitab Kuning di Pesantren Kawasan Timur Indonesia\r\n\r\n', 'Pesantren termasuk lembaga pendidikan keagamaan tertua di Indonesia. Sejarah pesantren oleh berbagai pakar tidak bisa dipisahkan dengan kajian kitab kuning. Dalam berbagai definisi tentang pesantren, kajian kuning menjadi salah satu unsur di samping kiai, santri, masjid, dan asrama. Seiring dengan perjalanan waktu, sistem pembelajaran atau kurikulum di pesantren tidak hanya mengacu pada kajian kitab kuning. Banyak pesantren sudah mengakomodasi kurikulum dari Kementerian Pendidikan Nasional dan Kementerian Agama. Akibatnya, kajian kitab kuning menjadi tereduksi.    Di samping itu, pesantren di Nusantara juga  mengalami transformasi dalam berbagai bentuk. Sehingga, kajiannya bukan saja terkait pada kajian-kajian keagamaan, namun lebih luas pada kajian nonagama. Kemudian ditemukan di beberapa tempat pesantren berbasis seperti teknik mesin, agrobisnis, kebaharian, dan lain sebagainya. Pada akhirnya kajian kitab kuning bukan satu-satunya kajian yang paling urgen di pesantren. Bahkan banyak pesantren yang sudah tidak mengajarkan kitab kuning lagi.\r\n\r\n', 'https://mitra.nu.or.id/post/read/104342/pembelajaran-kitab-kuning-di-pesantren-kawasan-timur-indonesia-'),
(8, 'Menekuni Kajian Kitab di Pondok Pesantren Hidayatullah Depok', 'Kajian kitab ulama ini pun menjadi bahan kajian rutin di Pondok Pesantren Hidayatullah Depok. Kajian kitab merupakan program khusus untuk menambah pengetahuan dan wawasan keagamaan warga pesentren termasuk para santri.\r\nKajian kitab disisi oleh para pengurus pesantren yang kompeten di bidangnya diantaranya Ketua Yayasan Pondok Pesantren Hidayatullah Ustadz Lalu Mabrul, Ketua DKM Ustadz Hafidh Bahar Hamdan Al Hafidz, Ketua Bidang Kepengasuhan SMP dan MA Ustadz Najibullah, Ketua Perguruan Sekolah Tinggi Ilmu Ekonomi Ustadz DR Agus Suprayogi serta ustadz-ustadz lainnya.', 'https://hidayatullahdepok.org/2019/11/03/menekuni-kajian-kitab-di-pondok-pesantren-hidayatullah-depok/'),
(9, 'PEMBELAJARAN KITAB KUNING DI PESANTREN MUSTHAFAWIYAH, MANDAILING NATAL', 'Kitab kuning sejak lama menjadi bagian penting studi Islam di Indonesia, sejak era pertumbuhannya sampai kini. Pesantren, dan agak belakangan madrasah, menjadi garda terdepan dalam pengkajian dan pelestarian khazanah kitab kuning di Nusantara. Kitab-kitab yang dikaji meliputi bidang tafsir, hadis, tauhid, fikih, sampai bidang tasawuf. Penelitian pembelajaran kitab kuning selama ini memang dirasa masih berfokus pada kawasan Jawa yang memang bisa dikatakan basis pesantren di Nusantara. Selain itu diketahui ada sejumlah perubahan dalam sistem pembelajaran kitab kuning di pesantren. Secara khusus,', 'http://jurnal.uinsu.ac.id/index.php/JCIMS/article/view/324'),
(10, 'MQK Ajang Silaturrahim Revitalisasi Pesantren dan Kajian Kitab Kuning', 'Melalui kajian kitab kuning, pesantren mendapat pemahaman yang moderat. Kyai dan ustadz sering merujuk kitab kuning. Tradisi kajian kitab kuning jadi roh keagamaan.\r\nMQK diinisiasi oleh sejumlah kyai pesantren dan dimotori KH Said Aqil Munawwar yang saat itu menjabat sebagai Menteri Agama. Tradisi itu terus dipelihara dengan beberapa peningkatan. MQK mulai tahun depan diselenggarakan dua tahun sekali.', 'https://akurat.co/news/id-91616-read-mqk-ajang-silaturrahim-revitalisasi-pesantren-dan-kajian-kitab-kuning'),
(11, 'Di Tengah Pandemi, Kajian Kitab Kuning Digelar secara Online di Ponpes Asshodiqiyah Semarang\r\n\r\n\r\n', 'Wabah pandemi virus corona Covid-19 tak menyurutkan antusias kegiatan keislaman selama bulan Ramadhan.\r\nSeperti dicontohkan puluhan santriwan-santriwati Pondok Pesantren (Ponpes) Asshodiqiyah, Gayamsari, Kota Semarang, yang mendalami kitab kuning secara online, Sabtu (25/4/2020).\r\nPengajian kitab kuning secara online diperuntukan bagi para santri yang kini sedang berlibur panjang.\r\n\r\n', 'https://jateng.tribunnews.com/2020/04/25/di-tengah-pandemi-kajian-kitab-kuning-digelar-secara-online-di-ponpes-asshodiqiyah-semarang'),
(12, 'PONPES ITTIHAADUL ULUM PERTAHANKAN KAJIAN KITAB KUNING', 'Pondok pesantren (Ponpes) Ittihaadul Ulum Kota Lubuklinggau hingga saat ini masih mempertahan tradisi mengaji kitan kuning. Kitab kuning juga disebut kitab salaf sudah menjadi aktivitas sehari-hari para santri setiap malam, termasuk para santri Ponpes Ittihaadul Ulum.\r\n\r\n“Kitab kuning tidak dapat dipelajari dalam waktu instan. Karena kitab ini tidak ada harakatnya, membuat pendalaman kitab berlangsung dalam rentang yang cukup lama, sampai bertahun-tahun,” jelas Pimpinan Ponpes Ittihaadul Ulum, Drs. A.Sultoni.', 'https://sumsel.kemenag.go.id/berita/view/226376/ponpes-ittihaadul-ulum-pertahankan-kajian-kitab-kuning-'),
(13, 'Pendidikan Pesantren melalui kajian kitab klasik', 'Empat Perbedaan Al Quran dan Kitab-Kitab Sebelumnya Menurut Syeh Sha’rawi al Masri\r\nIbadah.co.id –Syeh Sha’rawi pernah menjelaskan dalam salah satu pengajiannya tentang perbedaan antara Al Quran dan Kitab-kitab sebelumnya.\r\nApakah Al Quran dengan kita-kitab terdahulu mempunyai perbedaan? Jika beda, lantas apa saja perbedaan itu?. Itulah rentetan pertanyaan dari salah satu jamaah kajian tafsirnya yang dialamatkan kepada Syeh Sha’rowi.', 'https://ibadah.co.id/islamika/tafsir/empat-perbedaan-al-quran-dan-kitab-kitab-sebelumnya-menurut-syeh-sharawi-al-masri/'),
(14, 'Ponpes Pancasila Salatiga Isi Ramadhan dengan Kajian Kitab Kuning', 'uasana Pondok Pesantren (Ponpes) Pancasila yang berada di Blotongan, Kecamatan Sidorejo, Kota Salatiga selama Ramadhanberbeda dengan hari biasa. Ponpes yang diasuh oleh Kiai Haji Muhlasin ini memiliki tradisi melakukan kajian kitab kuning selama bulan puasa.\r\n\r\nPara santri dan santriwati yang duduk terpisah sangat antusias menyimak keterangan dari ustaz yang mengulas kajian kitab kuning. Kajian ini wajib bagi kelas 1, 2 dan 3 pondok. Kelas 1, terdiri dari siswa MI/SD, kelas II dari MTS, dan kelas III dari SMK dan perguruan tinggi.\r\najian kitab kuning itu dilakukan setelah salat asar. Tidak itu saja, ada lagi kajian agama yang dilakukan setelah salat subuh. Kegiatan tersebut setiap hari diikuti ratusan santri dan santriwati.', 'https://daerah.sindonews.com/read/30745/707/ponpes-pancasila-salatiga-isi-ramadhan-dengan-kajian-kitab-kuning-1589537100'),
(15, 'Kitab Kuning tidak lagi Populer di Ponpes\r\n\r\n', 'PENGAJIAN kitab kuning di pondok pesantren semakin berkurang. Dahulu kitab kuning digunakan sebagai basis keilmuan, tapi kini dipandang kurang strategis. “Saya merasa prihatin. Kajian kitab kuning di sejumlah pesantren saat ini, berdasarkan hasil penelitian, semakin berkurang, padahal terdapat ribuan kitab kuning yang dapat dipelajari para santri karya ulama besar di Tanah Air atau luar negeri,” kata Menteri Agama Lukman Hakim Saifuddin pada acara Halaqah Pimpinan Ponpes se-Lampung\r\n\r\n', 'https://mediaindonesia.com/read/detail/41157-kitab-kuning-tidak-lagi-populer-di-ponpes'),
(16, 'Dinamika Kajian Kitab Kuning di Pesantren', 'ecara keseluruha, lima bahasan pokok dalam buku ini diharapkan dapat menjelaskan sisi historis dan subtansi kitab kuning, baik dari sudut keilmuan, kepenulisan, dan karakter khusus dalam kaitannya dengan dinamika kajian kitab kuning di pesantren. Di sini, kita tidak hanya bisa berkenalan dengan dunia kitab kuning secara umum, namun lebih dari itu, kita akan dibawa masuk berkenalan ke dalam khazanah dunia kitab kuning secara detail, menelisik masuk ke dalam sub-sub ilmu-ilmu keislaman yang jarang dijangkau oleh buku-buku kebanyakan.', 'https://sidogiri.net/2015/11/dinamika-kajian-kitab-kuning-di-pesantren/'),
(17, 'Pondok Pesantren Darul Akhyar', 'Syafaat selanjutnya adalah bagi “orang yang seharusnya masuk neraka, lalu dikeluarkan dari sana.” Ada juga syafaat untuk “menambah kedudukan di surga.” Berikutnya adalah “syafaat untuk satu kaum yang shalih yang ada kekurangan mereka dalam ketaatan lalu dimaafkan oleh Allah SWT”. Ada juga syafaat untuk “mengeluarkan orang bertauhid dari neraka.” Syafaat ini tidak khusus diberikan oleh Nabi SAW namun termasuk juga diberikan oleh para nabi (lainnya), malaikat, dan orang-orang beriman.', 'https://ponpesdarulakhyar.wordpress.com/2020/03/06/macam-macam-syafaat/'),
(18, 'Hanya di FUHum, Ada Kajian Kitab Metode Pesantren', 'Kegiatan ini sudah kita rumuskan bersama-sama dengan seluruh perwakilan lembaga mahasiswa dan Unit Kegiatan Mahasiswa (UKM), jadi tidak tiba-tiba. Kamis lalu telah dimulai dan dibuka langsung oleh Pak Dekan,\" ujar Musyafiq saat diwawancarai usai kegiatan kajian kitab.\r\nKajian kitab itu sebagai ikhtiyar kita bersama untuk menghidupkan kualitas tri etika kampus, ukhwah, diniyah, dan ilmiah. Selain PKM berisi aktivis yang getol berkegiatan, tapi juga gemar membangun kualifikasi akademik', 'https://www.ideapers.com/2016/09/hanya-fuhum-ada-kajian-kitab-metode-pesantren.html?m=0'),
(19, 'GELIAT KAJIAN KITAB KUNING DI KALANGAN SANTRI MILENIAL IBU KOTA', 'Beberapa hari yang lalu, tepatnya pada Senin 19 Agustus 2019, Pesantren Miftahul Ulum Gandaria dan Pesantren Darus-Sunnah Ciputat berkolaborasi menggelar bahtsul masail antar pesantren. Kegiatan yang dipusatkan di aula pesantren Miftahul Ulum itu diikuti oleh puluhan santri, baik delegasi dari Madrasah Darus-Sunnah ataupun Pesantren Miftahul Ulum. Dimulai tepat pukul 20.30 WIB hingga berakhir pukul 23.00 WIB. Selama hampir tiga jam ini, mereka mendiskusikan problem kekinian berbasis kitab kuning.', 'http://darussunnah.ponpes.id/catatan-singkat-bahtsul-masail-antar-pesantren-miftahul-ulum-dan-darus-sunnah/'),
(20, 'Kajian Kitab Klasik dan Cerita Seputar Santri', 'ekilas mengenai kajian kitab klasik, redaksi akan menyajikan isi yang terkandung dalam kitab “Idhotun Nasyiin” karangan ulama besar Musthafa Al-Ghalayani. Kitab yang membahas tentang akhlaq, etika, dan kemasyarakatan.\r\nKitab atau buku yang ditulis seorang pemikir dan reformisi ini, berisi bimbingan untuk generasi muda muslim ‘Jaman Now. Dengan harapan menjadi manusia seutuhnya, berhiaskan akhlaq terpuji dan mengerti permasalahan yang dialami bangsa.\r\nDi dalam pengantar buku, pengarang menyebut, jika kitab Idhotun Nasyiin merupakan kumpulan nasihat berharga yang pernah ditulis di Koran Al-Mufid, dengan judul Nasihat Untuk Generasi Muda, di bawah asuhan Abu Fayyadh.', 'http://bloktuban.com/2018/05/17/kajian-kitab-klasik-dan-cerita-seputar-santri/');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `berita`
--
ALTER TABLE `berita`
  ADD KEY `hasil` (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `berita`
--
ALTER TABLE `berita`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
